//
//  BaseModelAPI.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 22.02.23.
//

import Foundation

protocol BasemodelAPI {
    func shopID() -> String
    
}

extension BasemodelAPI {
    
    func shopID() -> String { return "" }
    
}





