//
//  ProdTypeView.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 24.02.23.
//

import SwiftUI

struct ProdTypeView: View {
    //Erstellt ein Object vom Typ Sellable
    let productTypeDepartment: ProductTypeDepartment


    var body: some View {
        VStack {
            VStack{
                
                
            }
            
            VStack {
                List{
                    Text(productTypeDepartment.name)
                    Text("ID: " + productTypeDepartment.id)
                    Text("Weight: \(productTypeDepartment.weight)")
                    Text(productTypeDepartment.name)
                        .font(.headline)
                    ForEach(productTypeDepartment.categories, id: \.id) { category in
                        Text("Category: \(category.name)")
                        // hier können Sie weitere Informationen zur Kategorie darstellen
                    }
                }
                
            }
              
            
        }
    
    }
}

struct ProdTypeView_Previews: PreviewProvider {
    static var previews: some View {
        ProdTypeView(productTypeDepartment: ProductTypeDepartment(name: "Active Wear", weight: 1, categories: [Category(name: "Sport", nameSingular: "Sport", productTypes: [], id: "85")], lifeCycleState: "ACTIVATED", id: "11", href: "https://assortment.spreadshirt.net/api/v1/shops/100247767/productTypeDepartments/11"))
    }
}
