//
//  SellablesResponse.swift
//  NewAPITest
//
//  Created by Timo Schönbeck on 21.02.23.
//

import Foundation

struct SellablesResponse: Codable {
    var count: Int
    var limit: Int
    var offset: Int
    var sellables: [Sellable]
}
