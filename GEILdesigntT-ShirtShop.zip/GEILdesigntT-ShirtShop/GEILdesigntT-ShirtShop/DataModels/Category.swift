//
//  Category.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 24.02.23.
//

import Foundation

struct Category: Codable {
    let name: String
    let nameSingular: String
    let productTypes: [ProductTypeReference]
    let id: String
}
