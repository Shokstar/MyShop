//
//  ProductTypeReference.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 24.02.23.
//

import Foundation

struct ProductTypeReference: Codable {
    let href: String
    let id: String
}
