//
//  Price.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 22.02.23.
//

import Foundation

struct Price: Codable {
    var amount: Double //Eine Gleitkommazahl, die den Betrag des Preises darstellt.
    var currencyId: String //Eine Zeichenfolge, die die Währung des Preises darstellt.
}
