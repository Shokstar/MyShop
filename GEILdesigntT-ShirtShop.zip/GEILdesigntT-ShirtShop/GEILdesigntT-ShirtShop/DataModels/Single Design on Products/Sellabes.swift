//
//  Sellabes.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 22.02.23.
//

import Foundation

// Die Struktur "Sellable" definiert eine Datenstruktur, die die Eigenschaften eines Produkts aus dem Spreadshirt-Shop enthält.
struct Sellable: Codable {
    var sellableId: String // ID des verkaufbaren Produkts
    var ideaId: String // ID der Idee
    var mainDesignId: String // ID des Hauptdesigns
    var productTypeId: String // ID des Produkttyps
    var price: Price // Preis des Produkts
    var name: String // Name des Produkts
    var description: String // Beschreibung des Produkts
    var tags: [String] // Schlagwörter des Produkts
    var previewImage: ImageData // Vorschaubild des Produkts
    var appearanceIds: [String] // IDs der Designs
    var defaultAppearanceId: String // ID des Standarddesigns
}
