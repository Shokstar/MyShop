//
//  ImageData.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 22.02.23.
//

import Foundation

struct ImageData: Codable {
    var url: String   // Die URL des Bildes
    var type: String  // Der Typ des Bildes, z.B. "jpg", "png", usw.
}

