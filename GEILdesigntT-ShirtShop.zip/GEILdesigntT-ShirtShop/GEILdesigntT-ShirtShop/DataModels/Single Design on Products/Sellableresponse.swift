//
//  Sellableresponse.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 22.02.23.
//

import Foundation

struct SellablesResponse: Codable {
    var count: Int       // Anzahl der zurückgegebenen Artikel
    var limit: Int       // maximale Anzahl von Artikeln, die auf einer Seite angezeigt werden können
    var offset: Int      // Index des ersten zurückgegebenen Artikels auf der aktuellen Seite
    var sellables: [Sellable]   // Array von verkaufsfähigen Artikeln
}

