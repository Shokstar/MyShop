//
//  ProductTypeDepartment.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 24.02.23.
//

import Foundation

struct ProductTypeDepartment: Codable {
    let name: String
    let weight: Int
    let categories: [Category]
    let lifeCycleState: String
    let id: String
    let href: String
}


