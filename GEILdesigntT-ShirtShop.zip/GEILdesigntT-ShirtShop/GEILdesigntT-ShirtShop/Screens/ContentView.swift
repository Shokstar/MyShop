//
//  ContentView.swift
//  NewAPITest
//
//  Created by Timo Schönbeck on 21.02.23.
//

import SwiftUI


struct ContentView: View {
    // Speichert die abgerufenen Produkte
    @State var sellables: [Sellable] = []
    @State var count: Int = 1
    @State var limit: Int = 1
    @State var selectedNumber = 0
 
    
    
    
    var body: some View {

        VStack {
            // Wenn noch keine Produkte geladen wurden
            if sellables.isEmpty {
                // Anzeige, dass die Produkte gerade geladen werden
                Text("Loading...")
            } else {
                // Liste mit den Produkten
                List(sellables, id: \.sellableId) { sellable in
                    VStack(alignment: .center) {
                        // Name des Produkts
                        Text(sellable.name)
                            .font(.system(size: 16, weight: .bold, design: .monospaced))
                            .bold()
                       
                        
                    
                            // Vorschau des Produkts
                            SellableView(sellable: sellable)
                                .scaledToFit()
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                       
                            VStack {
                                // Beschreibung des Produkts
                                Text(sellable.description)
                                    .font(.subheadline)
                          
                                
                                // Preis des Produkts
                                Text("Price: \(String(format: "%.2f", sellable.price.amount))€ ")
                                    .font(.subheadline)
                                    .bold()
    
                         
                            
                           
                        }
                        
                      
                    }
                }
            }
            Spacer()
            
            // Button zum Abrufen der Produkte
            Button("Produkte") {
                fetchSellables()
                
            }
            .padding()
            .background(Color.red)
            .foregroundColor(.white)
            .bold()
            .clipShape(RoundedRectangle(cornerRadius: 20))
            
        }
        //        .onAppear {
        //                    // Ruft die Produkte automatisch ab, sobald die View geladen wird
        //                    fetchSellables()
        //                }
        
    }
    
    
    func pageLimit(count: Int, limit: Int) -> Int{
        return count / limit
    }
    
    //MARK: Func
        func fetchSellables() {
        // URL der API zum Abrufen der Produkte
        let url = URL(string: "https://api.spreadshirt.net/api/v1/shops/100247767/sellables?page=\(Int.random(in: 0...pageLimit(count: count, limit: limit)))&SprdAuth%20apiKey=%22b1271341-2d14-468b-a6ed-d28ba13034c0%22")!
        // HTTP-Methode zum Abrufen der Produkte
    
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            // Überprüft, ob Daten empfangen wurden
            guard let data = data else {
                // Fehlermeldung, wenn keine Daten empfangen wurden
                print("API request failed: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            do {
                // Decodiert die empfangenen Daten in ein Array von Produkten
                let sellablesResponse = try JSONDecoder().decode(SellablesResponse.self, from: data)
                // Speichert die abgerufenen Produkte in der State-Variable
                DispatchQueue.main.async {
                    self.sellables = sellablesResponse.sellables
                    self.count = sellablesResponse.count
                    self.limit = sellablesResponse.limit
                }
            } catch {
                // Fehlermeldung, wenn die Daten nicht decodiert werden können
                print("Failed to decode API response: \(error.localizedDescription)")
            }
        }
        // Startet den Datenabruf
        .resume()
    }
    
//    func fetchProducTypeDepartments() {
//    // URL der API zum Abrufen der Produkte
//    let url = URL(string: "https://api.spreadshirt.net/api/v1/shops/100247767/productTypeDepartments?mediaType=json&fullData=true&?SprdAuth%20apiKey=%22b1271341-2d14-468b-a6ed-d28ba13034c0%22")!
//    // HTTP-Methode zum Abrufen der Produkte
//
//    var request = URLRequest(url: url)
//    request.httpMethod = "GET"
//
//    URLSession.shared.dataTask(with: request) { data, response, error in
//        // Überprüft, ob Daten empfangen wurden
//        guard let data = data else {
//            // Fehlermeldung, wenn keine Daten empfangen wurden
//            print("API request failed: \(error?.localizedDescription ?? "Unknown error")")
//            return
//        }
//
//        do {
//            // Decodiert die empfangenen Daten in ein Array von Produkten
//            let sellablesResponse = try JSONDecoder().decode(SellablesResponse.self, from: data)
//            // Speichert die abgerufenen Produkte in der State-Variable
//            DispatchQueue.main.async {
//                self.sellables = sellablesResponse.sellables
//                self.count = sellablesResponse.count
//                self.limit = sellablesResponse.limit
//            }
//        } catch {
//            // Fehlermeldung, wenn die Daten nicht decodiert werden können
//            print("Failed to decode API response: \(error.localizedDescription)")
//        }
//    }
//    // Startet den Datenabruf
//    .resume()
//}
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
