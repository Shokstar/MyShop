//
//  GEILdesigntT_ShirtShopApp.swift
//  GEILdesigntT-ShirtShop
//
//  Created by Timo Schönbeck on 22.02.23.
//

import SwiftUI

@main
struct GEILdesigntT_ShirtShopApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
