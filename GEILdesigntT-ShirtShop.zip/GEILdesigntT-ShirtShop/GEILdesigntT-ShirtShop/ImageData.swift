//
//  ImageData.swift
//  NewAPITest
//
//  Created by Timo Schönbeck on 21.02.23.
//

import Foundation

struct ImageData: Codable {
    var url: String
    var type: String
}
